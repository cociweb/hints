# Documentation

* Contributing
    * [Edit on Github](github/README.md)
    * [Codespace](codespace/README.md)
    * [Local fork](forking/README.md)
* Sentence templates
    * [Template syntax](templates.md)
    * [YAML format](../sentences/README.md)
* Test sentences
    * [YAML format](../tests/README.md)
* Response templates
    * [YAML format](../responses/README.md)
