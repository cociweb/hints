# Contributing

Our contributing guide lines can be found in [the Voice developer documentation](https://developers.home-assistant.io/docs/voice/intent-recognition/contributing).
